# Email Spam Detection
 
Title: Email Spam Classification (Naïve Bayes Algorithm)

Team members:
Ambar Kambli – 28

Aim: To create Email spam classifier for demonstrating Multinomial
Naïve Bayes Algorithm.

Technical details:
Frontend: Streamlit(Python)
Backend: Python, sklearn

![image](https://user-images.githubusercontent.com/33069451/126063810-397514b3-1952-4ed8-ad26-4313a0bd0245.png)
